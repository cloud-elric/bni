<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=gomcommx_bni',
    'username' => 'gomcommx_GeekDeveloper',
    'password' => 'c0d1ngG33k',
    'charset' => 'utf8',
];
